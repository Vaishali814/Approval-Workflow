const db = require('../config/db');

exports.getByRequest = (requestId, callback) => {
  db.query(
    `SELECT * FROM audit_logs WHERE entity_id = ? ORDER BY performed_at`,
    [requestId],
    (err, rows) => callback(rows)
  );
};
