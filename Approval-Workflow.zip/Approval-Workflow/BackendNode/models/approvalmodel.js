const db = require('../config/db');

exports.save = (requestId, role, action) => {
  db.query(
    `INSERT INTO approvals (request_id, approval_role, action)
     VALUES (?, ?, ?)`,
    [requestId, role, action]
  );
console.log("hello approval");

  db.query(
    `UPDATE requests SET status = ? WHERE request_id = ?`,
    [action, requestId]
  );
};
