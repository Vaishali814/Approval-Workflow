const db= require('../config/db');

exports.create=(amount,createdby, cbFunction)=>{
    const sql=`insert into requests (amount, status, created_by) 
    values (?,'pending',?)`;

    db.query(sql, [amount,createdby],(err, result)=>{
        if(err) throw err;
        cbFunction(result);
    });
};



exports.getPendingByRole = (role, cbFunction) => {
  let status = '';

  if (role === 'MANAGER') status = 'PENDING_MANAGER';
  else if (role === 'FINANCE') status = 'PENDING_FINANCE';
  else status = 'pending'; // default (employee)

  const sql = `
    SELECT r.*, u.name 
    FROM requests r
    JOIN users u ON r.created_by = u.user_id
    WHERE r.status = ?
  `;

  db.query(sql, ["pending"], (err, result) => {
    if (err) throw err;
    console.log(result);
    
    cbFunction(result);
  });
};
