const express = require('express');
const router = express.Router();
const db = require('../config/db');
router.post('/', (req, res) => {
  const { name, role } = req.body;

  db.query(
    `INSERT INTO users (name, role) VALUES (?, ?)`,
    [name, role],
    (err, result) => {
      if (err) return res.status(500).json(err);
      res.json({ message: 'User created', userId: result.insertId });
    }
  );
});

module.exports = router;

