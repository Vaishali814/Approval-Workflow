const auditModel = require('../models/auditModel');

exports.getLogs = (req, res) => {
  auditModel.getByRequest(req.params.requestId, (logs) => {
    res.json(logs);
  });
};
