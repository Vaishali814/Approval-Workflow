const requestModel=require('../models/requestmodel');
const auditLogger=require('../utils/auditlogger');

exports.createrequest=(req,res)=>{
    
      
    const{amount, createdBy}=req.body;

    requestModel.create(amount, createdBy, (result)=>{
        auditLogger('REQUEST', result.insertId,"RequestCreated", createdBy);
        res.json({message:"Request Created", requestId:result.insertId});
    });
};

exports.getPendingByRole = (req, res) => {
  const { role } = req.query;

  requestModel.getPendingByRole(role, (data) => {
    res.json(data);
  });
};




