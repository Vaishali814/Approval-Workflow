const approvalModel = require('../models/approvalModel');
const auditLogger = require('../utils/auditlogger');

exports.takeAction = (req, res) => {
  const { requestId, action, approverId, role } = req.body;

  approvalModel.save(requestId, role, action);

  auditLogger('REQUEST', requestId, action, approverId);

  res.json({ message: `Request ${action}` });
};
