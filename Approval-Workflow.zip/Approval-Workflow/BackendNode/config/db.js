const mysql=require('mysql2');

const db=mysql.createConnection({
host:"localhost",
user:"root",
password:"root",
database:"approval_workflow"
})

db.connect(err=>{
    if(err){
            console.log("DB connection failed", err);
            
    }
    else{
                console.log("Db Connected with server MySQl");
                
    }
});
module.exports=db;