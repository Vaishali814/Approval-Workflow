const db= require('../config/db');

module.exports=(entity,entityid,action, userid)=>{
    const sql=`insert into audit_logs (entity,entity_id,action, performed_by) 
    values (?,?,?,?)`;

    db.query(sql, [entity,entityid,action, userid]);
};