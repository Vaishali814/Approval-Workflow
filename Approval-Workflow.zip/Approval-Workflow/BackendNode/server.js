const express=require("express");
const app=express();
const cors=require('cors');
app.use(cors());
app.use(express.json());

app.use('/api/requests', require('./routes/requestroutes'));
app.use('/api/approvals', require('./routes/approvalroutes'));
app.use('/api/audit', require('./routes/auditroutes'));
app.use('/api/users', require('./controllers/usercontroller'));

app.listen(3000,()=>{
    console.log("server is running at 3000");
    
});