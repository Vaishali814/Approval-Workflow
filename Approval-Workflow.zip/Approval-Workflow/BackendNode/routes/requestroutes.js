
const express=require("express");
const router=express.Router();

const requestController=require("../controllers/requestcontroller");

router.post('/', requestController.createrequest);
router.get('/pending', requestController.getPendingByRole);
module.exports=router;