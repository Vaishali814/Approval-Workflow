import { useState } from 'react';
import CreateRequest from './components/CreateRequest';
import ApprovalList from './components/ApprovalList';

function App() {
  const [role, setRole] = useState('');

  if (!role) {
    return (
      <div>
        <h2>Select Role</h2>
        <button onClick={() => setRole('EMPLOYEE')}>Employee</button>
        <button onClick={() => setRole('MANAGER')}>Manager</button>
        <button onClick={() => setRole('FINANCE')}>Finance</button>
      </div>
    );
  }

  return (
    <div>
      <h2>Logged in as {role}</h2>

      {role === 'EMPLOYEE' && <CreateRequest />}
      {role === 'MANAGER' && <ApprovalList role="MANAGER" />}
      {role === 'FINANCE' && <ApprovalList role="FINANCE" />}
    </div>
  );
}

export default App;
