import { useState } from 'react';
import API from '../services/api';

export default function CreateRequest() {
  const [amount, setAmount] = useState('');
  const [createdBy, setCreatedBy] = useState('');

  const submitRequest = async () => {
    await API.post('/requests', {
      amount,
      createdBy
    });
    alert('Request Created');
  };

  return (
    <div>
      <h3>Create Expense Request</h3>
      <input
        type="number"
        placeholder="Amount"
        onChange={(e) => setAmount(e.target.value)}
      />
      <input
        
        placeholder="User"
        onChange={(e) => setCreatedBy(e.target.value)}
      />
      <button onClick={submitRequest}>Submit</button>
    </div>
  );
}
