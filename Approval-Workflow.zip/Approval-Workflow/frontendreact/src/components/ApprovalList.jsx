import { useEffect, useState } from 'react';
import API from '../services/api';

export default function ApprovalList({ role }) {
  const [requests, setRequests] = useState([]);

  useEffect(() => {
    API.get(`/requests/pending?role=${role}`)
      .then(res => setRequests(res.data));
  }, [role]);

  const takeAction = (id, action) => {
    API.post('/approvals', {
      requestId: id,
      approverId: role === 'MANAGER' ? 2 : 3,
      role,
      action
    }).then(() => alert(action + ' successfully'));
  };

  return (
    <div>
      <h3>{role} Approval Inbox</h3>
      {requests.map(r => (
        <div key={r.requestId}>
          ₹{r.amount}
          <button onClick={() => takeAction(r.requestId, 'APPROVED')}>Approve</button>
          <button onClick={() => takeAction(r.requestId, 'REJECTED')}>Reject</button>
        </div>
      ))}
    </div>
  );
}
