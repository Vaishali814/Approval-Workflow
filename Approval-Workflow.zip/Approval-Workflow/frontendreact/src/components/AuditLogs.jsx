import { useEffect, useState } from 'react';
import API from '../services/api';

export default function AuditLogs({ requestId }) {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    API.get(`/audit/${requestId}`)
      .then(res => setLogs(res.data));
  }, [requestId]);

  return (
    <div>
      <h4>Audit Logs</h4>
      <ul>
        {logs.map((log, i) => (
          <li key={i}>
            {log.action} by User {log.performed_by}
          </li>
        ))}
      </ul>
    </div>
  );
}
